# FAQs

If you have a question not answered here, leave an issue on our [github-issue](https://github.com/GazzolaLab/PyElastica/issues).

## Q. Is there support available for Elastica?

If you open an issue on [GitHub](https://github.com/GazzolaLab/PyElastica), we will look and respond within 24-48 hours.
