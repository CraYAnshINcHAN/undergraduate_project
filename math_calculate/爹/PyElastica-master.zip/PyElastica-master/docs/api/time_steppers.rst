Time steppers
==============
.. automodule:: elastica.timestepper.symplectic_steppers
   :members:
   :exclude-members: __weakref__, __init__,  _SystemCollectionStepperMixin, SymplecticLinearExponentialIntegrator, SymplecticStepper


