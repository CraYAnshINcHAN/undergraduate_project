## Note

- Assets contains image/video for tutorial or documentation.
- **Avoid unnecessary binary change of the files. Any file included here will remain permanently without update.**
- As an alternative, consider using `google drive` or `Box` and make url link instead of using repo.
- We decided to postpone using `git lfs`.
