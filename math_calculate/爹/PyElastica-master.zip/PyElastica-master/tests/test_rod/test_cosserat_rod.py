__doc__ = """ Cosserat rod module import test"""

# System imports


if __name__ == "__main__":
    from pytest import main

    main([__file__])
