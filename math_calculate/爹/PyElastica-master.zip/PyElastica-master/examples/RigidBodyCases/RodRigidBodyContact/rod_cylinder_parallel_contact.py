from rod_cylinder_contact import rod_cylinder_contact_case


if __name__ == "__main__":
    inclination_angle = 0.0
    rod_cylinder_contact_case(inclination_angle=inclination_angle)
